package com.example.stopwatch

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import org.w3c.dom.Text
import java.util.*
import kotlin.concurrent.timer

class MainActivity : AppCompatActivity() {

    private var time = 0;
    private var timerTask: Timer? = null // 초기값을 null로 설정
    private var isRunning = false // 플래그 변수
    private var lap = 1

    lateinit var fab : FloatingActionButton
    lateinit var secTextView : TextView
    lateinit var milliTextView : TextView
    lateinit var labLayout : LinearLayout
    lateinit var labButton : Button
    lateinit var resetFab : FloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        fab = findViewById<FloatingActionButton>(R.id.fab)
        secTextView = findViewById<TextView>(R.id.secTextView)
        milliTextView = findViewById<TextView>(R.id.milliTextView)
        labLayout = findViewById<LinearLayout>(R.id.labLayout)
        labButton = findViewById(R.id.labButton)
        resetFab = findViewById(R.id.resetFab)

        // fab 클릭될 때
        fab.setOnClickListener {
            isRunning = !isRunning // 클릭될 때 start(), pause()로 상태를 바꿔줌

            if (isRunning) {
                start()
            } else {
                pause()
            }
        }

        // 랩타임 버튼 클릭될 때
        labButton.setOnClickListener {
            recordLapTime() // 함수 호출
        }

        resetFab.setOnClickListener {
            reset()
        }
    }

    private fun pause() {
        fab.setImageResource(R.drawable.ic_baseline_play_arrow_24)
        timerTask?.cancel() // 타이머 정지
    }

    // 타이머 시작할 때 호출되는 메소드
    private fun start() {
        fab.setImageResource(R.drawable.ic_baseline_pause_24) // fab을 일시정지 이미지로 변경

        timerTask = timer(period=10) {
            time++ // 시간 계산 변수
            val sec = time / 100
            val milli = time % 100

            // UI 갱신
            runOnUiThread {
                secTextView.text = "$sec" // 초 값을 출력
                milliTextView.text = "$milli" // 밀리초 값을 출력
            }
        }


    }

    // 랩타임 기록 메소드
    private fun recordLapTime() {
        val lapTime = this.time // 현재 시간을 가져옴
        val textView = TextView(this) // 현재 액티비티에 텍스트뷰 생성
        textView.text = "$lap LAB : ${lapTime/100}.${lapTime%100}"

        labLayout.addView(textView, 0) // 인덱스 0에 계속 추가함.
        lap++
    }

    //
    private fun reset() {
        timerTask?.cancel() // 타이머의 모든 동작을 취소

        time = 0
        isRunning = false
        fab.setImageResource(R.drawable.ic_baseline_play_arrow_24)
        secTextView.text = "0"
        milliTextView.text = "00"

        labLayout.removeAllViews() // 모두 초기화
        lap = 1
    }
}