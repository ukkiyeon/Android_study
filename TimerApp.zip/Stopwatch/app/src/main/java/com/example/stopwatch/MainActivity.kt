package com.example.stopwatch

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import org.w3c.dom.Text
import java.util.*
import kotlin.concurrent.timer

class MainActivity : AppCompatActivity() {

    private var time = 0;
    private var timerTask: Timer? = null // 초기값을 null로 설정
    private var isRunning = false // 플래그 변수
    private var lap = 1

    lateinit var secTextView : TextView
    lateinit var milliTextView : TextView
    lateinit var secEditText : EditText
    lateinit var setButton : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        secTextView = findViewById<TextView>(R.id.secTextView)
        milliTextView = findViewById<TextView>(R.id.milliTextView)
        secEditText = findViewById(R.id.secEditText)
        setButton = findViewById(R.id.setButton)

        setButton.setOnClickListener {
            time = secEditText.text.toString().toInt()*100 // 입력된 시간에 * 100
            start()
        }
    }

    // 타이머 시작할 때 호출되는 메소드
    private fun start() {
        timerTask = timer(period=10) {
            time-- // 시간 계산 변수
            val sec = time / 100
            val milli = time % 100

            if(sec == 0 && milli == 0) timerTask?.cancel() // 타이머 정지

           // UI 갱신
            runOnUiThread {
                secTextView.text = "$sec" // 초 값을 출력
                milliTextView.text = "$milli" // 밀리초 값을 출력
            }
        }
    }
}